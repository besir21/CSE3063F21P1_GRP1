import json
import random
import logging

class Person:
    def __init__(self,Ssn=None,Name=None,Lastname=None,email=None,birthDate=None):
        self.Ssn=Ssn
        self.Name=Name
        self.LastName=Lastname
        self.email=email
        self.birthDate=birthDate
    def toString(self):
        print self.Ssn,self.Name,self.LastName

class Professor:
    def __init__(self,degree=None,WeeklySchedule=None,PersonObj=Person ,prasentedCourses=[]):
        self.degree=degree
        self.WeeklySchedule=WeeklySchedule
        self.Person=Person
        self.prasentedCourses=prasentedCourses
    def toString(self):
        self.Person.toString()

class Student:
    def __init__(self,StudentID,EnrolledYear,WeeklySchedule,Transcript,Person=Person):
        self.StudentID=StudentID
        self.Person=Person
        self.EnrolledYear=EnrolledYear
        self.WeeklySchedule=WeeklySchedule
        self.Transcript=Transcrip
    def toString(self):
        self.Person.toString()

class Advisor:
    def __init__(self,students=[]):
        self.students=students
    def AdvisedStudent(self):
        for i in self.students:
            print i.toSting()

class Course:
    def __init__(self,courseCode,CourseTitle,givenSemester,courseSchedule):
        self.courseCode=courseCode
        self.CourseTitle=CourseTitle
        self.givenSemester=givenSemester
        self.courseSchedule=courseSchedule

class Transcrip:
    def __init__(self,semester,gpa,totalgpa,passedcredits,failedcredits,coursepassed,coursefailed,courseNotTaken,activeCourse):
        self.semester=semester
        self.gpa=gpa
        self.totalgpa=totalgpa
        self.passedcredits=passedcredits
        self.failedcredits=failedcredits
        self.coursepassed=coursepassed
        self.coursefailed=coursefailed
        self.courseNotTaken=courseNotTaken
        self.activeCourse=activeCourse
    def ShowTranscript(self):
        pass

class ElectiveCourse:

    def __init__(self,electiveCourseCode,electiveCourseTitle):
        self.electiveCourseCode=electiveCourseCode
        self.electiveCourseTitle=electiveCourseTitle

class Schedule:
    def __init__(self,CourseTime):
        self.CourseTime=CourseTime
    def Schedule(self):
        pass

