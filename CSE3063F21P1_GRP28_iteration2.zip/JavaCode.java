﻿package Model1;

class Person extends Professor implements Professor
{
    private String ssn;		
    private String name;		
    private String lastname;		
    private String email;		
    private int birthDate;		
    private int age;		

    
    
    
     final void person()
    {
        
    }    
    
    
     final int person(object ssn.string, string name, string lastname, string email, int birthdate, int age)
    {
        
    }    
    
    
     final void getSsn()(object string)
    {
        
    }    
    
    
     final void setSsn(string):void (ssn)
    {
        
    }    
    
    
     final void getName(object string)
    {
        
    }    
    
    
     final void setName(void (name.string))
    {
        
    }    
    
    
     final void getlastname(object string)
    {
        
    }    
    
    
     final void setlastname(string):void (lastname)
    {
        
    }    
    
    
     final void getemail(object string)
    {
        
    }    
    
    
     final void setemail(string):void (email)
    {
        
    }    
    
    
     final void getbirthdate(object int)
    {
        
    }    
    
    
     final void setbirthdate(int):void (birthdate)
    {
        
    }    
    
    
     final void getage(object int)
    {
        
    }    
    
    
     final void setage(int):void (age)
    {
        
    }    
    
    
     final void toString(object string)
    {
        
    }    
}

package Model1;

class Professor extends Person implements Person
{
    private String degree;		
    private ArrayList<course> presentedcourses;		
    private Schedule weeklySchedule;		

    
    
    
     final void ınstructur()
    {
        
    }    
    
    
     final void ınstructure(string ssn, string name, string lastname, string email, int birthdate, int age, string degree, arraylist<Courses> presentedcourses, schedule weeklySchdule)
    {
        
    }    
    
    
     final void getdegree(object string)
    {
        
    }    
    
    
     final void setdegree(string):void (degree)
    {
        
    }    
    
    
     final void getpresentedcourses(object arraylist<Course>)
    {
        
    }    
    
    
     final void setpresentedcourses(ArrayList<Course>) : void (presentedCourses)
    {
        
    }    
    
    
     final void getweeklyschedule(object schedule)
    {
        
    }    
    
    
     final void setweeklyschedule(Schedule) : void (weeklySchedule)
    {
        
    }    
    
    
     final void tostring(object string)
    {
        
    }    
}

package Model1;

class student extends Person implements Person
{
    private studentıd studentıd;		
    private int yearenrolled;		
    private schedule weeklyschedule;		
    private transcript previousTranscript;		
    private transcript currenttranscript;		
    private ArrayList<Course> collisionCourses;		
    private ArrayList<String> logs;		
    
}

package Model1;

//
class COURSE
{
    //
    private String COURSECODE;		
    //
    private String coursetitle;		
    //
    private Semester givensemester;		
    //
    private Schedule CourseSchedule;		
    //
    private ArrayList<Student> students;		
    //
    private int courseCredit;		
    //
    private ArrayList<String> prerequisites;		
    //
    private String section;		
    //
    private int quota;		
    //
    private String type;		
    //
    private int numOfStudents;		
    //
    private int hourCollisionCounter;		
    //
    private int prerequisiteFailureCounter;		
    
}

package Model1;

//
class studentıd
{
    //
    private int order;		
    //
    private String id;		
    //
    private String = "1501" departmentCode;		
    //
    private int year;		
    
}

package Model1;

//
class transcript
{
    //
    private int semester;		
    //
    private ArrayList<Double> gpa;		
    //
    private double totalGpa;		
    //
    private ArrayList<Integer> passedCredits;		
    //
    private ArrayList<Integer> failedCredits;		
    //
    private ArrayList<ArrayList<Object[]>> coursesPassed;		
    //
    private ArrayList<ArrayList<Object[]>> courseFailed;		
    //
    private ArrayList<Object[]> coursesNotTaken;		
    //
    private ArrayList<Object[]> activeCourses;		
    
}

package Model1;

//
class advisor extends Person implements Person
{
    //
    private ArrayList<Student> students;		
    
}

package Model1;

//
class schdule
{
    //
    private int courseTime;		
    
}

package Model1;

//
class electivecourse
{
    //
    private String electiveCourseCode;		
    //
    private String electiveCourseTitle;		
    
}

package Model1;

//
class registration
{
    //
    private int = 0 semesterCount;		
    
}

package Model1;

//
class semester
{
    //
    private int num;		
    //
    private String name;		
    
}

